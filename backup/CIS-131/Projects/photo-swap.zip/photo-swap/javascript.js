// Vert, David; 9/26/2018; JavaScript source code

// No change in code needed! Just add more image files into the array!

var img = ["try().jpg", "jQPGrx.jpg", "program.jpg", "error.jpg", "code-horror.jpg", "java2javascript.jpg"];

var i = 0;

function imgSet() {

    var t = document.createElement('title');
    t.innerHTML = 'Photo Swap';
    document.head.appendChild(t)

    var l = document.createElement('link');
    l.rel = 'shortcut icon';
    l.type = 'image/x-icon';
    l.href = 'insanity.jpg';
    document.head.appendChild(l);

    document.body.style.backgroundColor = 'azure';

    for (i = 0; i < img.length; i++) {
        var x = new Image;
        x.src = img[i];
        x.alt = 'img';
        x.id = i;
        x.style.width = '14%';
        x.style.padding = '1.2%';
        x.onclick = bigscreen;
        document.body.appendChild(x);
    }

    var x = document.createElement('audio');
    x.src = 'Elfen.Lied.Lilium.music.box.mp3';
    x.setAttribute('loop', 'true');
    x.play();

    var y = document.createElement('img');
    y.id = 'important';
    y.src = img[0];
    y.alt = 'music';
    y.style.width = '100%';
    document.body.appendChild(y);
}

function bigscreen() {
    document.getElementById("important").src = img[this.id];
}

window.addEventListener("load", imgSet);